package com.ejazati.app;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.net.Uri;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    final int NAVY=Color.rgb(23,40,63), BEIGE=Color.rgb(244,238,226), GOLD=Color.rgb(185,155,105), WHITE=Color.WHITE;
    final String PREF="ejazati_store", KEY="data";
    JSONArray workers=new JSONArray(), leaves=new JSONArray(), audit=new JSONArray();
    String password="";
    LinearLayout root, content, nav;
    static final String[] DAYS={"السبت","الأحد","الإثنين","الثلاثاء","الأربعاء","الخميس","الجمعة"};
    static final String[] TYPES={"إجازة سنوية","إجازة مرضية","إجازة اضطرارية","إجازة زواج","إجازة وفاة","إجازة أخرى"};
    static final String[] STATUSES={"معتمدة","بانتظار الموافقة","مرفوضة"};

    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(NAVY); getWindow().setNavigationBarColor(NAVY); load(); if(password.isEmpty()) setupPassword(); else login(); }
    void load(){
        try { JSONObject d=new JSONObject(getSharedPreferences(PREF,0).getString(KEY,"{}"));
            workers=d.optJSONArray("workers"); if(workers==null)workers=new JSONArray();
            leaves=d.optJSONArray("leaves"); if(leaves==null)leaves=new JSONArray();
            audit=d.optJSONArray("audit"); if(audit==null)audit=new JSONArray();
            password=d.optString("password","");
        }catch(Exception e){workers=new JSONArray();leaves=new JSONArray();audit=new JSONArray();}
    }
    void save(){
        try { JSONObject d=new JSONObject(); d.put("workers",workers);d.put("leaves",leaves);d.put("audit",audit);d.put("password",password);
            getSharedPreferences(PREF,0).edit().putString(KEY,d.toString()).apply();
        }catch(Exception ignored){}
    }
    void log(String action){try{JSONObject x=new JSONObject();x.put("action",action);x.put("at",new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date()));audit.put(x);}catch(Exception ignored){}}
    void setupPassword(){
        LinearLayout box=screen(); title("مرحباً بك في إجازتي"); TextView t=txt("أنشئ كلمة مرور المدير لحماية بيانات المتجر",16,NAVY);box.addView(t);
        EditText p=edit("كلمة المرور",true);box.addView(p); EditText c=edit("تأكيد كلمة المرور",true);box.addView(c);
        Button b=button("حفظ وبدء الاستخدام");box.addView(b); b.setOnClickListener(v->{if(p.getText().length()<4){msg("كلمة المرور يجب ألا تقل عن 4 أحرف");return;}if(!p.getText().toString().equals(c.getText().toString())){msg("كلمتا المرور غير متطابقتين");return;}password=p.getText().toString();save();home();});
    }
    void login(){
        LinearLayout box=screen();title("إجازتي");box.addView(txt("دخول المدير",18,NAVY));EditText p=edit("كلمة المرور",true);box.addView(p);Button b=button("دخول");box.addView(b);
        b.setOnClickListener(v->{if(password.equals(p.getText().toString()))home();else msg("كلمة المرور غير صحيحة");});
    }
    LinearLayout screen(){
        root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(BEIGE);root.setPadding(24,24,24,16);setContentView(root);return root;
    }
    TextView txt(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.RIGHT);t.setPadding(4,8,4,8);return t;}
    EditText edit(String hint,boolean pass){EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(16);e.setHint(hint);e.setGravity(Gravity.RIGHT);if(pass)e.setInputType(129);return e;}
    Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(NAVY));return b;}
    void title(String s){TextView t=txt(s,25,NAVY);t.setTypeface(null,1);root.addView(t);}
    void msg(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    void home(){
        screen(); LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setOrientation(1);
        TextView h=txt("إجازتي",28,NAVY);h.setTypeface(null,1);header.addView(h);header.addView(txt("إدارة إجازات العمال",14,GOLD));root.addView(header);
        LinearLayout stats=new LinearLayout(this);stats.setOrientation(0);stats.setPadding(0,12,0,12);
        stats.addView(stat("العمال",String.valueOf(workers.length())));stats.addView(stat("الإجازات",String.valueOf(leaves.length())));root.addView(stats);
        nav=new LinearLayout(this);nav.setOrientation(0);String[] labels={"الرئيسية","العمال","الإجازات","النسخ"};
        for(int i=0;i<labels.length;i++){final int n=i;Button b=button(labels[i]);b.setTextSize(11);nav.addView(b,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));b.setOnClickListener(v->{if(n==0)home();if(n==1)workerPage();if(n==2)leavePage();if(n==3)backupPage();});}
        root.addView(nav); ScrollView sc=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(1);sc.addView(content);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        card("ملخص المتجر","يوم العمل: 6 أيام أسبوعياً\nيوم راحة أسبوعي مستقل لكل عامل\nطريقة الحساب: أيام العمل فقط\nالمدير وحده يدير جميع البيانات");
        card("آخر الإجازات", "عدد السجلات: "+leaves.length()+"\nيمكنك مراجعة سجل كل عامل من قسم الإجازات.");
        Button add=button("＋ إضافة عامل");content.addView(add);add.setOnClickListener(v->addWorker());
    }
    LinearLayout stat(String label,String value){LinearLayout x=new LinearLayout(this);x.setOrientation(1);x.setBackgroundColor(WHITE);x.setPadding(14,12,14,12);x.setLayoutParams(new LinearLayout.LayoutParams(0,-2,1));x.addView(txt(value,24,NAVY));x.addView(txt(label,13,GOLD));return x;}
    void card(String head,String body){LinearLayout c=new LinearLayout(this);c.setOrientation(1);c.setBackgroundColor(WHITE);c.setPadding(16,12,16,12);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,8,0,8);content.addView(c,lp);TextView a=txt(head,18,NAVY);a.setTypeface(null,1);c.addView(a);c.addView(txt(body,14,Color.DKGRAY));}
    void workerPage(){homeShell("العمال");Button add=button("إضافة عامل جديد");content.addView(add);add.setOnClickListener(v->addWorker());
        for(int i=0;i<workers.length();i++){JSONObject w=workers.optJSONObject(i);if(w==null)continue;final String id=w.optString("id");card(w.optString("name"),"الهاتف: "+w.optString("phone","—")+"\nيوم الراحة: "+DAYS[w.optInt("off",0)]+"\nالرصيد السنوي: "+w.optInt("balance",0)+" يوم");
            Button ed=button("تعديل بيانات العامل");content.addView(ed);ed.setOnClickListener(v->editWorker(id));}
    }
    void homeShell(String title){screen();title(title);nav=new LinearLayout(this);String[] labels={"الرئيسية","العمال","الإجازات","النسخ"};for(int i=0;i<4;i++){final int n=i;Button b=button(labels[i]);b.setTextSize(10);nav.addView(b,new LinearLayout.LayoutParams(0,-2,1));b.setOnClickListener(v->{if(n==0)home();if(n==1)workerPage();if(n==2)leavePage();if(n==3)backupPage();});}root.addView(nav);ScrollView s=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(1);s.addView(content);root.addView(s,new LinearLayout.LayoutParams(-1,0,1));}
    void addWorker(){workerDialog(null);}
    void editWorker(String id){workerDialog(findWorker(id));}
    JSONObject findWorker(String id){for(int i=0;i<workers.length();i++){JSONObject w=workers.optJSONObject(i);if(w!=null&&id.equals(w.optString("id")))return w;}return null;}
    void workerDialog(JSONObject old){
        LinearLayout f=new LinearLayout(this);f.setOrientation(1);EditText name=edit("اسم العامل",false),phone=edit("رقم الهاتف",false),balance=edit("الرصيد السنوي بالأيام",false);
        Spinner off=new Spinner(this);off.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,DAYS));
        if(old!=null){name.setText(old.optString("name"));phone.setText(old.optString("phone"));balance.setText(""+old.optInt("balance"));off.setSelection(old.optInt("off"));}
        f.addView(name);f.addView(phone);f.addView(balance);f.addView(txt("يوم الراحة الأسبوعي",14,NAVY));f.addView(off);
        new AlertDialog.Builder(this).setTitle(old==null?"إضافة عامل":"تعديل عامل").setView(f).setNegativeButton("إلغاء",null).setPositiveButton("حفظ",(d,w)->{
            if(name.getText().toString().trim().isEmpty()){msg("أدخل اسم العامل");return;}
            try{JSONObject obj=old==null?new JSONObject():old;obj.put("id",old==null?UUID.randomUUID().toString():old.optString("id"));obj.put("name",name.getText().toString().trim());obj.put("phone",phone.getText().toString());obj.put("balance",Math.max(0,Integer.parseInt(balance.getText().toString().isEmpty()?"0":balance.getText().toString())));obj.put("off",off.getSelectedItemPosition());if(old==null)workers.put(obj);log(old==null?"إضافة عامل":"تعديل عامل: "+obj.optString("name"));save();workerPage();}catch(Exception e){msg("تحقق من الرصيد المدخل");}
        }).show();
    }
    void leavePage(){homeShell("الإجازات");Button add=button("تسجيل إجازة جديدة");content.addView(add);add.setOnClickListener(v->addLeave());
        for(int i=0;i<leaves.length();i++){JSONObject l=leaves.optJSONObject(i);if(l==null)continue;String state=l.optString("status");card(l.optString("workerName")+" — "+l.optString("type"),"من "+l.optString("start")+" إلى "+l.optString("end")+"\nأيام العمل: "+l.optInt("days")+"\nالحالة: "+state+"\nالخصم: "+(l.optBoolean("deduct")?"نعم":"لا"));
            if(state.equals("بانتظار الموافقة")){Button approve=button("اعتماد الإجازة");content.addView(approve);approve.setOnClickListener(v->{try{l.put("status","معتمدة");applyDeduction(l);log("اعتماد إجازة "+l.optString("workerName"));save();leavePage();}catch(Exception e){}});}
        }
    }
    void addLeave(){
        if(workers.length()==0){msg("أضف عاملاً أولاً");return;}
        LinearLayout f=new LinearLayout(this);f.setOrientation(1);
        String[] names=new String[workers.length()];for(int i=0;i<workers.length();i++)names[i]=workers.optJSONObject(i).optString("name");
        Spinner who=new Spinner(this);who.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names));
        Spinner type=new Spinner(this);type.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,TYPES));
        EditText start=edit("تاريخ البداية yyyy-MM-dd",false),end=edit("تاريخ النهاية yyyy-MM-dd",false);start.setText(new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date()));end.setText(start.getText());
        Spinner status=new Spinner(this);status.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,STATUSES));
        CheckBox deduct=new CheckBox(this);deduct.setText("خصم الأيام من الرصيد السنوي");deduct.setTextColor(NAVY);
        f.addView(txt("العامل",14,NAVY));f.addView(who);f.addView(txt("نوع الإجازة",14,NAVY));f.addView(type);f.addView(start);f.addView(end);f.addView(txt("حالة الإجازة",14,NAVY));f.addView(status);f.addView(deduct);
        new AlertDialog.Builder(this).setTitle("تسجيل إجازة").setView(f).setNegativeButton("إلغاء",null).setPositiveButton("حفظ",(d,x)->{
            try{JSONObject worker=workers.optJSONObject(who.getSelectedItemPosition());Date a=parse(start.getText().toString()),b=parse(end.getText().toString());if(b.before(a))throw new Exception();
                int days=countWorkDays(a,b,worker.optInt("off"));JSONObject l=new JSONObject();l.put("id",UUID.randomUUID().toString());l.put("workerId",worker.optString("id"));l.put("workerName",worker.optString("name"));l.put("type",type.getSelectedItem().toString());l.put("start",start.getText().toString());l.put("end",end.getText().toString());l.put("days",days);l.put("deduct",deduct.isChecked());l.put("status",status.getSelectedItem().toString());leaves.put(l);if(l.optString("status").equals("معتمدة"))applyDeduction(l);log("تسجيل إجازة "+worker.optString("name"));save();leavePage();
            }catch(Exception e){msg("التاريخ غير صحيح. استخدم yyyy-MM-dd وتأكد أن النهاية بعد البداية.");}
        }).show();
    }
    Date parse(String s)throws Exception{return new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(s);}
    int countWorkDays(Date a,Date b,int off){Calendar c=Calendar.getInstance();c.setTime(a);Calendar z=Calendar.getInstance();z.setTime(b);int n=0;while(!c.after(z)){int dow=c.get(Calendar.DAY_OF_WEEK);int day=(dow==Calendar.SATURDAY?0:dow==Calendar.SUNDAY?1:dow==Calendar.MONDAY?2:dow==Calendar.TUESDAY?3:dow==Calendar.WEDNESDAY?4:dow==Calendar.THURSDAY?5:6);if(day!=off)n++;c.add(Calendar.DATE,1);}return n;}
    void applyDeduction(JSONObject l)throws Exception{if(!l.optBoolean("deduct")||l.optBoolean("deducted"))return;JSONObject w=findWorker(l.optString("workerId"));if(w!=null){w.put("balance",Math.max(0,w.optInt("balance")-l.optInt("days")));l.put("deducted",true);}}
    void backupPage(){homeShell("النسخ الاحتياطي");card("حماية بياناتك","صدّر نسخة من بيانات العمال والإجازات والأرصدة وسجل العمليات، أو استعد نسخة سابقة.");
        Button ex=button("تصدير نسخة احتياطية");content.addView(ex);ex.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"Ejazati-backup.json");startActivityForResult(i,41);});
        Button im=button("استعادة نسخة احتياطية");content.addView(im);im.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");startActivityForResult(i,42);});
    }
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null)return;try{
        if(req==41){JSONObject d=new JSONObject();d.put("format","ejazati-backup-v1");d.put("workers",workers);d.put("leaves",leaves);d.put("audit",audit);d.put("password",password);OutputStream o=getContentResolver().openOutputStream(data.getData());o.write(d.toString(2).getBytes("UTF-8"));o.close();msg("تم تصدير النسخة الاحتياطية بنجاح");}
        if(req==42){InputStream in=getContentResolver().openInputStream(data.getData());ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;while((n=in.read(buf))>0)out.write(buf,0,n);in.close();JSONObject d=new JSONObject(new String(out.toByteArray(),"UTF-8"));if(!"ejazati-backup-v1".equals(d.optString("format")))throw new Exception();new AlertDialog.Builder(this).setTitle("تأكيد الاستعادة").setMessage("سيتم استبدال البيانات الحالية ببيانات النسخة المختارة. هل تريد المتابعة؟").setNegativeButton("إلغاء",null).setPositiveButton("استعادة",(x,y)->{workers=d.optJSONArray("workers");leaves=d.optJSONArray("leaves");audit=d.optJSONArray("audit");password=d.optString("password",password);if(workers==null)workers=new JSONArray();if(leaves==null)leaves=new JSONArray();if(audit==null)audit=new JSONArray();log("استعادة نسخة احتياطية");save();home();msg("تمت الاستعادة");}).show();}
    }catch(Exception e){msg("تعذر قراءة النسخة الاحتياطية أو أن الملف غير صالح");}}
}
